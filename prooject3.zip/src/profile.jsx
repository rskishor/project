import React from "react";
import './img.css'

const Profile = () =>{
    return(
        <>
        <div id ="img"></div>
        
        
        
        
        
        
        
        
        </>
    );
};
export default Profile;